import React from 'react';
import {
  Router as DefaultRouter,
  Route,
  Switch,
  StaticRouter,
} from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@@/history';
import RendererWrapper0 from '/Users/changge/usmart/jetlinks-copy/src/pages/.umi/LocaleWrapper.jsx';
import { routerRedux, dynamic as _dvaDynamic } from 'dva';

const Router = routerRedux.ConnectedRouter;

const routes = [
  {
    path: '/user',
    routes: [
      {
        name: 'login',
        path: '/user/login',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__user__login2" */ '../user/login2'),
              LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                .default,
            })
          : require('../user/login2').default,
        exact: true,
      },
      {
        component: () =>
          React.createElement(
            require('/Users/changge/usmart/jetlinks-copy/node_modules/_umi-build-dev@1.18.9@umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
      },
    ],
  },
  {
    path: '/',
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () =>
            import(/* webpackChunkName: "layouts__SecurityLayout" */ '../../layouts/SecurityLayout'),
          LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
            .default,
        })
      : require('../../layouts/SecurityLayout').default,
    routes: [
      {
        path: '/',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "layouts__BasicLayout" */ '../../layouts/BasicLayout'),
              LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                .default,
            })
          : require('../../layouts/BasicLayout').default,
        Routes: [require('../Authorized').default],
        routes: [
          {
            path: '/',
            redirect: '/analysis',
            exact: true,
          },
          {
            name: '统计分析',
            path: '/analysis',
            icon: 'dashboard',
            tenant: ['admin', 'member'],
            iconfont: 'icon-tongjifenxi',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  app: require('@tmp/dva').getApp(),
                  models: () => [
                    import(/* webpackChunkName: 'p__analysis__model.tsx' */ '/Users/changge/usmart/jetlinks-copy/src/pages/analysis/model.tsx').then(
                      m => {
                        return { namespace: 'model', ...m.default };
                      },
                    ),
                  ],
                  component: () =>
                    import(/* webpackChunkName: "p__analysis" */ '../analysis'),
                  LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                    .default,
                })
              : require('../analysis').default,
            exact: true,
          },
          {
            path: '/system',
            name: '系统设置',
            iconfont: 'icon-shezhi',
            icon: 'setting',
            tenant: ['admin', 'member'],
            authority: [
              'user',
              'permission',
              'organization',
              'dictionary',
              'open-api',
              'admin',
              'system-config',
              'dimension',
              'tenant-side-manager',
              'tenant-manager',
            ],
            routes: [
              {
                path: '/system/user',
                name: '用户管理',
                iconfont: 'icon-yonghuguanli',
                icon: 'user',
                authority: ['user', 'admin'],
                tenant: ['admin', 'member'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__system__users__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/system/users/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../system/users'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../system/users').default,
                exact: true,
              },
              {
                path: '/system/permission',
                name: '权限管理',
                icon: 'key',
                iconfont: 'icon-quanxianguanli',
                authority: ['permission', 'admin'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__system__permission__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/system/permission/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../system/permission'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../system/permission').default,
                exact: true,
              },
              {
                path: '/system/open-api',
                name: '第三方平台',
                icon: 'share-alt',
                iconfont: 'icon-APIguanli',
                authority: ['open-api', 'admin'],
                version: 'pro',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__system__open-api__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/system/open-api/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../system/open-api'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../system/open-api').default,
                exact: true,
              },
              {
                path: '/system/org-chart',
                name: '机构管理',
                icon: 'apartment',
                authority: ['organization', 'admin'],
                tenant: ['admin', 'member'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../system/org-chart'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../system/org-chart').default,
                exact: true,
              },
              {
                hideInMenu: true,
                path: '/system/org-chart/assets/:id/:type',
                name: '资产分配',
                authority: ['organization', 'admin'],
                tenant: ['admin', 'member'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../assets'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../assets').default,
                exact: true,
              },
              {
                path: '/system/role',
                name: '角色管理',
                icon: 'usergroup-add',
                iconfont: 'icon-jiaoseguanli1',
                authority: ['dimension', 'admin'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__system__role__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/system/role/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../system/role'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../system/role').default,
                exact: true,
              },
              {
                path: '/system/config',
                name: '系统配置',
                icon: 'tool',
                iconfont: 'icon-xitongpeizhi',
                authority: ['system-config', 'admin'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../system/config'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../system/config').default,
                exact: true,
              },
              {
                path: '/system/tenant',
                name: '租户管理',
                icon: 'team',
                iconfont: 'icon-erji-zuhuguanli',
                tenant: ['admin'],
                authority: ['tenant-side-manager', 'tenant-manager', 'admin'],
                version: 'pro',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../system/tenant'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../system/tenant').default,
                exact: true,
              },
              {
                hideInMenu: true,
                path: '/system/tenant/detail/:id',
                name: '租户详情',
                tenant: ['admin'],
                authority: ['tenant-side-manager', 'tenant-manager', 'admin'],
                version: 'pro',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../system/tenant/detail'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../system/tenant/detail').default,
                exact: true,
              },
              {
                path: '/system/datasource',
                name: '数据源管理',
                icon: 'database',
                authority: ['datasource-config', 'admin'],
                version: 'pro',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../system/datasource'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../system/datasource').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('/Users/changge/usmart/jetlinks-copy/node_modules/_umi-build-dev@1.18.9@umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/device',
            name: '设备管理',
            icon: 'box-plot',
            tenant: ['admin', 'member'],
            iconfont: 'icon-device-manage',
            authority: [
              'device-product',
              'device-instance',
              'device-category',
              'device-group',
              'device-gateway',
              'geo-manager',
              'firmware-manager',
              'device-alarm',
            ],
            routes: [
              {
                path: '/device/product',
                name: '产品',
                icon: 'laptop',
                iconfont: 'icon-shebei',
                tenant: ['admin', 'member'],
                authority: ['device-product'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__device__product__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/device/product/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../device/product'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../device/product').default,
                exact: true,
              },
              {
                path: '/device/product-category',
                name: '产品分类',
                icon: 'appstore',
                iconfont: 'icon-shebei',
                tenant: ['admin', 'member'],
                version: 'pro',
                authority: ['device-category'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../device/product-category'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../device/product-category').default,
                exact: true,
              },
              {
                hideInMenu: true,
                path: '/device/product/save/:id',
                name: '产品详情',
                tenant: ['admin', 'member'],
                iconfont: 'icon-shebei',
                authority: ['device-product'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__device__product__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/device/product/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../device/product/save/Detail'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../device/product/save/Detail').default,
                exact: true,
              },
              {
                hideInMenu: true,
                path: '/device/product/add',
                name: '新建产品',
                tenant: ['admin', 'member'],
                iconfont: 'icon-shebei',
                authority: ['device-product'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__device__product__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/device/product/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../device/product/save/add/index.tsx'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../device/product/save/add/index.tsx').default,
                exact: true,
              },
              {
                path: '/device/instance',
                name: '设备',
                icon: 'desktop',
                tenant: ['admin', 'member'],
                iconfont: 'icon-shebei1',
                authority: ['device-instance'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__device__instance__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/device/instance/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../device/instance'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../device/instance').default,
                exact: true,
              },
              {
                hideInMenu: true,
                path: '/device/instance/save/:id',
                name: '设备详情',
                tenant: ['admin', 'member'],
                iconfont: 'icon-shebei1',
                authority: ['device-instance'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__device__instance__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/device/instance/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../device/instance/editor'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../device/instance/editor').default,
                exact: true,
              },
              {
                hideInMenu: true,
                path: '/device/group',
                name: '分组',
                icon: 'gold',
                tenant: ['admin', 'member'],
                authority: ['device-group'],
                version: 'pro',
                iconfont: 'icon-shebeifenzuguanli',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../device/group'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../device/group').default,
                exact: true,
              },
              {
                path: '/device/tree',
                name: '分组',
                tenant: ['admin', 'member'],
                authority: ['device-group'],
                version: 'pro',
                icon: 'gold',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../device/tree'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../device/tree').default,
                exact: true,
              },
              {
                hideInMenu: true,
                path: '/device/tree/detail',
                name: '分组详情',
                authority: ['device-group'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../device/tree/DeviceTree'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../device/tree/DeviceTree').default,
                exact: true,
              },
              {
                hideInMenu: true,
                path: '/device/instance/add',
                name: '添加设备',
                tenant: ['admin', 'member'],
                authority: ['device-instance'],
                iconfont: 'icon-shebeifenzuguanli',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__device__instance__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/device/instance/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../device/instance/editor'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../device/instance/editor').default,
                exact: true,
              },
              {
                path: '/device/gateway',
                name: '网关',
                icon: 'global',
                tenant: ['admin', 'member'],
                iconfont: 'icon-Group',
                authority: ['device-gateway'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__device__gateway__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/device/gateway/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../device/gateway'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../device/gateway').default,
                exact: true,
              },
              {
                path: '/device/location',
                name: '地理位置',
                icon: 'compass',
                tenant: ['admin'],
                authority: ['geo-manager'],
                version: 'pro',
                iconfont: 'icon-diliweizhi',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__device__location__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/device/location/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../device/location'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../device/location').default,
                exact: true,
              },
              {
                path: '/device/firmware',
                name: '固件升级',
                icon: 'cloud-sync',
                tenant: ['admin', 'member'],
                authority: ['firmware-manager'],
                version: 'pro',
                iconfont: 'icon-gujianshengji',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../device/firmware'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../device/firmware').default,
                exact: true,
              },
              {
                hideInMenu: true,
                tenant: ['admin', 'member'],
                path: '/device/firmware/save/:id',
                name: '固件详情',
                authority: ['firmware-manager'],
                iconfont: 'icon-gujianshengji',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../device/firmware/editor'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../device/firmware/editor').default,
                exact: true,
              },
              {
                path: '/device/alarm',
                name: '设备告警',
                icon: 'alert',
                tenant: ['admin', 'member'],
                authority: ['device-alarm'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../device/alarmlog'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../device/alarmlog').default,
                exact: true,
              },
              {
                path: '/device/command',
                name: '指令下发',
                icon: 'arrow-down',
                authority: ['device-msg-task'],
                version: 'pro',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../device/command'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../device/command').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('/Users/changge/usmart/jetlinks-copy/node_modules/_umi-build-dev@1.18.9@umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/network',
            name: '设备接入',
            iconfont: 'icon-shebei',
            icon: 'login',
            authority: [
              'certificate',
              'network-config',
              'device-gateway',
              'protocol-supports',
              'opc-client',
              'modbus-master',
            ],
            routes: [
              {
                path: '/network/certificate',
                name: '证书管理',
                icon: 'book',
                iconfont: 'icon-zhengshuguanli-',
                authority: ['certificate'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__network__certificate__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/network/certificate/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../network/certificate'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../network/certificate').default,
                exact: true,
              },
              {
                path: '/network/protocol',
                name: '协议管理',
                icon: 'wallet',
                iconfont: 'icon-xieyiguanli',
                authority: ['protocol-supports'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__device__protocol__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/device/protocol/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../device/protocol'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../device/protocol').default,
                exact: true,
              },
              {
                path: '/network/type',
                name: '网络组件',
                icon: 'deployment-unit',
                iconfont: 'icon-zujian',
                authority: ['network-config'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__network__type__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/network/type/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../network/type'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../network/type').default,
                exact: true,
              },
              {
                path: '/network/gateway',
                name: '设备网关',
                icon: 'cloud-server',
                iconfont: 'icon-shebei',
                authority: ['device-gateway'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__network__gateway__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/network/gateway/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../network/gateway'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../network/gateway').default,
                exact: true,
              },
              {
                path: '/network/opcua',
                name: 'OPC UA',
                icon: 'file-ppt',
                iconfont: 'icon-fileppt',
                authority: ['opc-client'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../network/opc-ua'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../network/opc-ua').default,
                exact: true,
              },
              {
                path: '/network/modbus',
                name: 'Modbus',
                icon: 'file-markdown',
                iconfont: 'file-markdown',
                authority: ['modbus-master'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../network/modbus'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../network/modbus').default,
                exact: true,
              },
              {
                path: '/network/modbus/:id',
                name: 'modbus设备接入',
                icon: 'file-markdown',
                iconfont: 'file-markdown',
                hideInMenu: true,
                authority: ['modbus-master'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../network/modbus/access'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../network/modbus/access').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('/Users/changge/usmart/jetlinks-copy/node_modules/_umi-build-dev@1.18.9@umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/notice',
            name: '通知管理',
            iconfont: 'icon-tongzhiguanli',
            icon: 'message',
            tenant: ['admin', 'member'],
            authority: ['template', 'notifier'],
            routes: [
              {
                path: '/notice/config',
                name: '通知配置',
                icon: 'alert',
                tenant: ['admin', 'member'],
                iconfont: 'icon-SUI_tongzhipeizhi',
                authority: ['notifier'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__notice__config__model.tsx' */ '/Users/changge/usmart/jetlinks-copy/src/pages/notice/config/model.tsx').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../notice/config'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../notice/config').default,
                exact: true,
              },
              {
                path: '/notice/template',
                name: '通知模版',
                icon: 'bell',
                tenant: ['admin', 'member'],
                iconfont: 'icon-tongzhiguanli',
                authority: ['template'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__notice__template__model.tsx' */ '/Users/changge/usmart/jetlinks-copy/src/pages/notice/template/model.tsx').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../notice/template'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../notice/template').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('/Users/changge/usmart/jetlinks-copy/node_modules/_umi-build-dev@1.18.9@umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/rule-engine',
            name: '规则引擎',
            icon: 'retweet',
            iconfont: 'icon-guizeyinqing',
            tenant: ['admin'],
            authority: ['rule-instance', 'rule-scene'],
            routes: [
              {
                path: '/rule-engine/instance',
                name: '规则实例',
                icon: 'block',
                tenant: ['admin'],
                iconfont: 'icon-hangweiguizeshili',
                authority: ['rule-instance'],
                version: 'pro',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__rule-engine__instance__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/rule-engine/instance/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../rule-engine/instance'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../rule-engine/instance').default,
                exact: true,
              },
              {
                path: '/rule-engine/sqlRule',
                name: '数据转发',
                icon: 'rise',
                tenant: ['admin'],
                iconfont: 'icon-datatransfer',
                authority: ['rule-instance'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__rule-engine__sqlRule__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/rule-engine/sqlRule/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../rule-engine/sqlRule'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../rule-engine/sqlRule').default,
                exact: true,
              },
              {
                path: '/rule-engine/scene',
                name: '场景联动',
                icon: 'codeSandbox',
                authority: ['rule-scene'],
                version: 'pro',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__rule-engine__scene__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/rule-engine/scene/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../rule-engine/scene'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../rule-engine/scene').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('/Users/changge/usmart/jetlinks-copy/node_modules/_umi-build-dev@1.18.9@umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/data-screen',
            name: '可视化',
            icon: 'desktop',
            tenant: ['admin'],
            iconfont: 'icon-icon-',
            version: 'pro',
            authority: ['visualization', 'admin'],
            routes: [
              {
                path: '/data-screen/project',
                name: '项目管理',
                icon: 'fund',
                iconfont: 'icon-screen',
                version: 'pro',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../data-screen/project'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../data-screen/project').default,
                exact: true,
              },
              {
                path: '/data-screen/datasource',
                name: '数据源管理',
                icon: 'database',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../data-screen/datasource'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../data-screen/datasource').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('/Users/changge/usmart/jetlinks-copy/node_modules/_umi-build-dev@1.18.9@umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/simulator',
            name: '模拟测试',
            icon: 'bug',
            version: 'pro',
            authority: ['network-simulator'],
            routes: [
              {
                path: '/simulator/device',
                name: '设备模拟器',
                version: 'pro',
                icon: 'paper-clip',
                authority: ['network-simulator'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../simulator/device'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../simulator/device').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('/Users/changge/usmart/jetlinks-copy/node_modules/_umi-build-dev@1.18.9@umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/logger',
            name: '日志管理',
            icon: 'calendar',
            iconfont: 'icon-rizhiguanli',
            authority: ['system-logger', 'access-logger'],
            routes: [
              {
                path: '/logger/access',
                name: '访问日志',
                icon: 'dash',
                iconfont: 'icon-yonghufangwenrizhi',
                authority: ['access-logger'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__logger__access__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/logger/access/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../logger/access'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../logger/access').default,
                exact: true,
              },
              {
                path: '/logger/system',
                name: '系统日志',
                icon: 'ordered-list',
                iconfont: 'icon-xitongrizhi',
                authority: ['system-logger'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__logger__system__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/logger/system/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../logger/system'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../logger/system').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('/Users/changge/usmart/jetlinks-copy/node_modules/_umi-build-dev@1.18.9@umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/cloud',
            name: '云云对接',
            icon: 'cloud',
            version: 'pro',
            authority: [
              'dueros-product',
              'aliyun-bridge',
              'onenet-product',
              'ctwing-product',
              'onelink-product',
            ],
            routes: [
              {
                path: '/cloud/duer',
                name: 'DuerOS',
                version: 'pro',
                authority: ['dueros-product'],
                icon: 'cloud',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../cloud/dueros'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../cloud/dueros').default,
                exact: true,
              },
              {
                path: '/cloud/aliyun',
                name: '阿里云',
                version: 'pro',
                authority: ['aliyun-bridge'],
                icon: 'aliyun',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../cloud/aliyun'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../cloud/aliyun').default,
                exact: true,
              },
              {
                path: '/cloud/onenet',
                name: '移动OneNet',
                version: 'pro',
                authority: ['onenet-product'],
                icon: 'mobile',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../cloud/onenet'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../cloud/onenet').default,
                exact: true,
              },
              {
                path: '/cloud/onelink',
                name: '移动OneLink',
                version: 'pro',
                icon: 'mobile',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../cloud/onelink'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../cloud/onelink').default,
                exact: true,
              },
              {
                path: '/cloud/ctwingCmp',
                name: '电信CTWingCmp',
                version: 'pro',
                icon: 'mobile',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../cloud/ctwingCmp'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../cloud/ctwingCmp').default,
                exact: true,
              },
              {
                path: '/cloud/ctwing',
                name: '电信CTWing',
                version: 'pro',
                authority: ['ctwing-product'],
                icon: 'phone',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../cloud/ctwing'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../cloud/ctwing').default,
                exact: true,
              },
              {
                path: '/cloud/unicom',
                name: '联通Unicom',
                version: 'pro',
                icon: 'mobile',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../cloud/unicomCmp'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../cloud/unicomCmp').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('/Users/changge/usmart/jetlinks-copy/node_modules/_umi-build-dev@1.18.9@umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/media',
            name: '视频网关',
            icon: 'youtube',
            version: 'pro',
            tenant: ['admin', 'member'],
            authority: [
              'gb28181-gateway',
              'media-gateway',
              'media-channel',
              'media-server',
              'media-stream',
              'gb28181-cascade',
            ],
            routes: [
              {
                path: '/media/basic',
                name: '基本配置',
                version: 'pro',
                tenant: ['admin', 'member'],
                authority: ['gb28181-gateway', 'media-gateway', 'media-server'],
                icon: 'video-camera',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../media/basic'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../media/basic').default,
                exact: true,
              },
              {
                path: '/media/device',
                name: '视频设备',
                version: 'pro',
                tenant: ['admin', 'member'],
                authority: ['media-device'],
                icon: 'gateway',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../media/device'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../media/device').default,
                exact: true,
              },
              {
                hideInMenu: true,
                path: '/media/device/channel/:id',
                name: '通道列表',
                version: 'pro',
                tenant: ['admin', 'member'],
                iconfont: 'icon-shebei1',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../media/device/channel'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../media/device/channel').default,
                exact: true,
              },
              {
                path: '/media/reveal',
                name: '分屏展示',
                version: 'pro',
                authority: ['media-stream'],
                tenant: ['admin', 'member'],
                icon: 'appstore',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../media/reveal'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../media/reveal').default,
                exact: true,
              },
              {
                path: '/media/cascade',
                name: '国标级联',
                version: 'pro',
                tenant: ['admin', 'member'],
                authority: ['gb28181-cascade'],
                icon: 'cloud-upload',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../media/cascade'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../media/cascade').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('/Users/changge/usmart/jetlinks-copy/node_modules/_umi-build-dev@1.18.9@umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/edge-gateway',
            name: '边缘网关',
            icon: 'gateway',
            authority: ['edge-product', 'edge-device'],
            routes: [
              {
                path: '/edge-gateway/product',
                name: '产品',
                icon: 'laptop',
                authority: ['edge-product'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../edge-gateway/product'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../edge-gateway/product').default,
                exact: true,
              },
              {
                path: '/edge-gateway/device',
                name: '设备',
                icon: 'desktop',
                authority: ['edge-device'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../edge-gateway/device'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../edge-gateway/device').default,
                exact: true,
              },
              {
                hideInMenu: true,
                path: '/edge-gateway/device/detail/:id',
                name: '设备详情',
                authority: ['edge-device'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../edge-gateway/device/detail'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../edge-gateway/device/detail').default,
                exact: true,
              },
              {
                hideInMenu: true,
                path: '/edge-gateway/device/detail/:id/save/:id',
                name: '网关设备详情',
                authority: ['edge-device'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../edge-gateway/device/detail/network/device/editor'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../edge-gateway/device/detail/network/device/editor')
                      .default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('/Users/changge/usmart/jetlinks-copy/node_modules/_umi-build-dev@1.18.9@umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/iot-card',
            name: '物联卡',
            icon: 'container',
            tenant: ['admin'],
            iconfont: 'icon-guizeyinqing',
            routes: [
              {
                path: '/iot-card/flow-card',
                name: '流量卡',
                icon: 'credit-card',
                tenant: ['admin'],
                iconfont: 'icon-xian-buguize-moxing',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__iot-card__flow-card__model.ts' */ '/Users/changge/usmart/jetlinks-copy/src/pages/iot-card/flow-card/model.ts').then(
                          m => {
                            return { namespace: 'model', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../iot-card/flow-card'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../iot-card/flow-card').default,
                exact: true,
              },
              {
                path: '/iot-card/query-transaction',
                name: '查询交易',
                icon: 'search',
                tenant: ['admin'],
                iconfont: 'icon-xian-buguize-moxing',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../iot-card/query-transaction'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../iot-card/query-transaction').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('/Users/changge/usmart/jetlinks-copy/node_modules/_umi-build-dev@1.18.9@umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            name: '波形分析',
            path: '/wave/list',
            icon: 'rise',
            iconfont: 'icon-datatransfer',
            tenant: ['admin', 'member'],
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__wave__list" */ '../wave/list'),
                  LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                    .default,
                })
              : require('../wave/list').default,
            exact: true,
          },
          {
            name: '波形分析',
            path: '/wave/info/:no',
            icon: 'dashboard',
            hideInMenu: true,
            tenant: ['admin', 'member'],
            iconfont: 'icon-tongjifenxi',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__wave__info" */ '../wave/info'),
                  LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                    .default,
                })
              : require('../wave/info').default,
            exact: true,
          },
          {
            path: '/account',
            name: '个人中心',
            icon: 'user',
            hideInMenu: true,
            routes: [
              {
                path: '/account/settings',
                name: '个人设置',
                icon: 'setting',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../account/settings'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../account/settings').default,
                exact: true,
              },
              {
                path: '/account/notification',
                name: '通知订阅',
                icon: 'bell',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../account/notification'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../account/notification').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('/Users/changge/usmart/jetlinks-copy/node_modules/_umi-build-dev@1.18.9@umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            name: 'exception',
            icon: 'smile',
            path: '/exception',
            hideInMenu: true,
            routes: [
              {
                path: '/exception/500',
                name: '500',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../exception/500'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../exception/500').default,
                exact: true,
              },
              {
                path: '/exception/404',
                name: '404',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../exception/404'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../exception/404').default,
                exact: true,
              },
              {
                path: '/exception/403',
                name: '403',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../exception/403'),
                      LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../exception/403').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('/Users/changge/usmart/jetlinks-copy/node_modules/_umi-build-dev@1.18.9@umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            component: () =>
              React.createElement(
                require('/Users/changge/usmart/jetlinks-copy/node_modules/_umi-build-dev@1.18.9@umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__404" */ '../404'),
              LoadingComponent: require('/Users/changge/usmart/jetlinks-copy/src/components/PageLoading/index')
                .default,
            })
          : require('../404').default,
        exact: true,
      },
      {
        component: () =>
          React.createElement(
            require('/Users/changge/usmart/jetlinks-copy/node_modules/_umi-build-dev@1.18.9@umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
      },
    ],
  },
  {
    component: () =>
      React.createElement(
        require('/Users/changge/usmart/jetlinks-copy/node_modules/_umi-build-dev@1.18.9@umi-build-dev/lib/plugins/404/NotFound.js')
          .default,
        { pagesPath: 'src/pages', hasRoutesInConfig: true },
      ),
  },
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

export { routes };

export default class RouterWrapper extends React.Component {
  unListen() {}

  constructor(props) {
    super(props);

    // route change handler
    function routeChangeHandler(location, action) {
      plugins.applyForEach('onRouteChange', {
        initialValue: {
          routes,
          location,
          action,
        },
      });
    }
    this.unListen = history.listen(routeChangeHandler);
    // dva 中 history.listen 会初始执行一次
    // 这里排除掉 dva 的场景，可以避免 onRouteChange 在启用 dva 后的初始加载时被多执行一次
    const isDva =
      history.listen
        .toString()
        .indexOf('callback(history.location, history.action)') > -1;
    if (!isDva) {
      routeChangeHandler(history.location);
    }
  }

  componentWillUnmount() {
    this.unListen();
  }

  render() {
    const props = this.props || {};
    return (
      <RendererWrapper0>
        <Router history={history}>{renderRoutes(routes, props)}</Router>
      </RendererWrapper0>
    );
  }
}
