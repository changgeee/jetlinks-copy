export interface CategoryItem {
    description: string,
    id: string,
    name: string,
    parentId: string,
    children: []
}