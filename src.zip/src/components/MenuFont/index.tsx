import { Icon } from "antd";
const url = require('./menu.js');

const MenuFont = Icon.createFromIconfontCN({
    scriptUrl: url,
})
export default MenuFont;