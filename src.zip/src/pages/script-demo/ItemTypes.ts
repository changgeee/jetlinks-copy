export default {
    FOOD: 'food',
    GLASS: 'glass',
    PAPER: 'paper',
}
