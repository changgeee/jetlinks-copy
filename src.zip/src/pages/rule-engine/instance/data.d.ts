export interface RuleInstanceItem {
    createTime: number;
    description: string;
    id: string;
    modelId: string;
    modelMeta: string;
    modelType: string;
    modelVersion: number;
    name: string;
    state: any;
}
