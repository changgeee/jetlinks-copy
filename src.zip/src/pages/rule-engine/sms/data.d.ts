export interface SmsItem {
    id: string;
    name: string;
    description: string;
    provider: string;
    configuration: any[];
}
