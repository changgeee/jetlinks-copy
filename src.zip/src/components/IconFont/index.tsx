import { Icon } from "antd";
const url = require('./iconfont.js');

const IconFont = Icon.createFromIconfontCN({
    scriptUrl: url,
})
export default IconFont;